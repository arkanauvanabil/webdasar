<nav class="navbar">
    <div class="navbar-container">
        <h3>SehatConnect - Admin</h3>
        <div class="nav-links">
            <a href="/sehatconnect/admin/index.php">Dashboard</a>   
            <a href="/sehatconnect/logout.php">Logout</a>
        </div>
    </div>
</nav>
<hr>
