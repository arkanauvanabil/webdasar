<footer style="text-align: center; margin-top: 40px; padding: 20px; color: #999;">
    <hr>
    <p>&copy; <?= date("Y") ?> SehatConnect Admin Panel</p>
</footer>
