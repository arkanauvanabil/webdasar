<?php
// admin_dashboard.php

$conn = new mysqli("localhost", "root", "", "sehatconnect_dokter");
if ($conn->connect_error) die("Koneksi gagal: " . $conn->connect_error);

// ========== TAMBAH DATA ==========
if (isset($_POST['tambah_klinik'])) {
    $nama = $_POST['nama_klinik'] ?? '';
    if (!empty($nama)) {
        $conn->query("INSERT INTO arkan_klinik(nama_klinik) VALUES ('$nama')");
    }
}

if (isset($_POST['tambah_dokter'])) {
    $nama = $_POST['nama_dokter'] ?? '';
    $spesialis = $_POST['spesialis'] ?? '';
    $klinik = $_POST['nama_klinik'] ?? '';
    if ($nama && $spesialis && $klinik) {
        $conn->query("INSERT INTO arkan_dokter(nama_dokter, spesialis, nama_klinik) VALUES ('$nama', '$spesialis', '$klinik')");
    }
}

if (isset($_POST['tambah_obat'])) {
    $nama = $_POST['nama_obat'] ?? '';
    $jenis = $_POST['jenis_obat'] ?? '';
    $harga = $_POST['harga'] ?? '';
    if ($nama && $jenis && $harga !== '') {
        $conn->query("INSERT INTO arkan_obat(nama_obat, jenis_obat, harga) VALUES ('$nama', '$jenis', '$harga')");
    }
}

if (isset($_POST['tambah_konsultasi'])) {
    $nama = $_POST['nama_pasien'] ?? '';
    $keluhan = $_POST['keluhan'] ?? '';
    $tanggal = $_POST['tanggal'] ?? '';
    $dokter = $_POST['nama_dokter'] ?? '';
    if ($nama && $keluhan && $tanggal && $dokter) {
        $conn->query("INSERT INTO arkan_konsultasi(nama_pasien, keluhan, tanggal, nama_dokter) VALUES ('$nama', '$keluhan', '$tanggal', '$dokter')");
    }
}

// ========== HAPUS DATA ==========
if (isset($_GET['hapus_klinik'])) $conn->query("DELETE FROM arkan_klinik WHERE id_klinik=" . intval($_GET['hapus_klinik']));
if (isset($_GET['hapus_dokter'])) $conn->query("DELETE FROM arkan_dokter WHERE id_dokter=" . intval($_GET['hapus_dokter']));
if (isset($_GET['hapus_obat'])) $conn->query("DELETE FROM arkan_obat WHERE id_obat=" . intval($_GET['hapus_obat']));
if (isset($_GET['hapus_konsultasi'])) $conn->query("DELETE FROM arkan_konsultasi WHERE id_konsultasi=" . intval($_GET['hapus_konsultasi']));
?>
