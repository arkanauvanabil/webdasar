<?php
// index.php
header("Location: login.php");
exit();
?>
