<nav class="navbar">
    <div class="navbar-container">
        <h3>SehatArkan - Pasien</h3>
        <div class="nav-links">
            <a href="/sehatconnect/user/index.php">Beranda</a>
            <a href="/sehatconnect/user/konsultasi.php">Konsultasi</a>
            <a href="/sehatconnect/user/dokter_list.php">Dokter</a>
            <a href="/sehatconnect/user/obat.php">Obat</a>
            <a href="/sehatconnect/logout.php" onclick="return confirm('Logout sekarang?')">Logout</a>
        </div>
    </div>
</nav>
<hr>
