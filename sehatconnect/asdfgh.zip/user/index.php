<?php
session_start();
include '../config/koneksi.php';
include 'partials/navbar.php';

// Query untuk daftar dokter
$dokter_result = $conn->query("SELECT d.*, k.nama_klinik FROM arkan_dokter d
                                LEFT JOIN arkan_klinik k ON d.id_klinik = k.id_klinik");

// Query untuk daftar obat
$obat_result = $conn->query("SELECT o.*, k.nama_klinik FROM arkan_obat o
                              LEFT JOIN arkan_klinik k ON o.id_klinik = k.id_klinik");

// Proses pengiriman konsultasi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../login.php");
        exit();
    }

    $id_user = $_SESSION['user_id'];
    $id_dokter = $_POST['id_dokter'];
    $keluhan = $_POST['keluhan'];

    $stmt = $conn->prepare("INSERT INTO arkan_konsultasi (id_user, id_dokter, keluhan) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $id_user, $id_dokter, $keluhan);
    if ($stmt->execute()) {
        echo "<script>alert('Konsultasi berhasil dikirim'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Gagal kirim konsultasi');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Dokter dan Obat</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Daftar Dokter</h2>
    <table>
        <tr>
            <th>Nama</th>
            <th>Spesialis</th>
            <th>Klinik</th>
        </tr>
        <?php while ($d = $dokter_result->fetch_assoc()): ?>
        <tr>
            <td><?= $d['nama_dokter'] ?></td>
            <td><?= $d['spesialis'] ?></td>
            <td><?= $d['nama_klinik'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <h2>Kirim Konsultasi</h2>
    <form method="post">
        <label>Pilih Dokter</label><br>
        <select name="id_dokter" required>
            <option value="">-- Pilih Dokter --</option>
            <?php
            // Reset pointer untuk query dokter
            $dokter_result->data_seek(0);
            while ($d = $dokter_result->fetch_assoc()): ?>
                <option value="<?= $d['id_dokter'] ?>">
                    <?= $d['nama_dokter'] ?> - <?= $d['spesialis'] ?> (<?= $d['nama_klinik'] ?>)
                </option>
            <?php endwhile; ?>
        </select><br><br>

        <label>Keluhan</label><br>
        <textarea name="keluhan" required style="width:100%; height:120px;"></textarea>
        <br><br>

        <button type="submit" class="btn">Kirim</button>
    </form>

    <h2>Obat Tersedia</h2>
    <table>
        <tr>
            <th>Nama Obat</th>
            <th>Jenis</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Klinik</th>
        </tr>
        <?php while ($o = $obat_result->fetch_assoc()): ?>
        <tr>
            <td><?= $o['nama_obat'] ?></td>
            <td><?= $o['jenis_obat'] ?></td>
            <td>Rp<?= number_format($o['harga']) ?></td>
            <td><?= $o['stok'] ?></td>
            <td><?= $o['nama_klinik'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>
<?php include 'partials/footer.php'; ?>
</body>
</html>
